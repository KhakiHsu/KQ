package com.kq.KQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KqApplication {

	public static void main(String[] args) {
		SpringApplication.run(KqApplication.class, args);
	}
}
